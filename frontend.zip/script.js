const db = firebase.database();
const produkList = document.getElementById('produk-list');
const keranjangEl = document.getElementById('keranjang');
let keranjang = [];

function tampilkanProduk(snapshot) {
  produkList.innerHTML = '';
  snapshot.forEach(child => {
    const data = child.val();
    const div = document.createElement('div');
    div.className = 'produk';
    div.innerHTML = `
      <img src="${data.gambar}" alt="${data.nama}">
      <h3>${data.nama}</h3>
      <p>Rp ${data.harga}</p>
      <button onclick="tambahKeKeranjang('${data.nama}', ${data.harga})">Tambah ke Keranjang</button>
    `;
    produkList.appendChild(div);
  });
}

db.ref('produk').on('value', tampilkanProduk);

function tambahKeKeranjang(nama, harga) {
  const item = { nama, harga, waktu: Date.now() };
  keranjang.push(item);
  firebase.database().ref('keranjang').push(item); // Simpan ke Firebase
  tampilkanKeranjang();
}


// Tampilkan isi keranjang
function tampilkanKeranjang() {
  keranjangEl.innerHTML = '';
  keranjang.forEach((item, index) => {
    const li = document.createElement('li');
    li.textContent = `${item.nama} - Rp ${item.harga}`;
    li.innerHTML += ` <button onclick="hapusDariKeranjang(${index})">Hapus</button>`;
    keranjangEl.appendChild(li);
  });
}

// Hapus item dari keranjang
function hapusDariKeranjang(index) {
  keranjang.splice(index, 1);
  tampilkanKeranjang();
}


if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/service-worker.js')
    .then(reg => console.log('Service Worker registered', reg))
    .catch(err => console.error('Service Worker failed', err));
}






