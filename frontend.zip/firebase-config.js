// firebase-config.js (COMPAT version)
const firebaseConfig = {
  apiKey: "AIzaSyDXGdI1DdBi9g05TNp2eElKieCY6vH_UX4",
  authDomain: "toko-online-6.firebaseapp.com",
  databaseURL: "https://toko-online-6-default-rtdb.firebaseio.com",
  projectId: "toko-online-6",
  storageBucket: "toko-online-6.appspot.com",
  messagingSenderId: "495012081052",
  appId: "1:495012081052:web:b5fac3f23e27c1ab392c59"
};

firebase.initializeApp(firebaseConfig);
